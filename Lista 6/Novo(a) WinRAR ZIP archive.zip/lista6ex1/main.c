/*
Objetivo: Mostrar na tela hello world!
Entrada:
Sa�da:
*/

#include <stdio.h>

int main(void) {
    printf("Hello world!\n");
    return 0;
}
